<?php
/**
 * Social-links.php
 *
 * @package float-plugin
 */

if ( ! function_exists( 'float_plugin_get_user_social_links' ) ) {
	/**
	 * Returns array of user's social links.
	 *
	 * @param  [int] $user_id User ID.
	 * @return [array]
	 */
	function float_plugin_get_user_social_links( $user_id ) {

		$services = array(
			'facebook'  => '_float_meta_facebook_url',
			'instagram' => '_float_meta_instagram_url',
			'pinterest' => '_float_meta_pinterest_url',
			'x'         => '_float_meta_twitter_url',
			'home'      => 'user_url',
		);

		$return = array();

		foreach ( $services as $service => $url ) {
			$url = get_the_author_meta( $url, $user_id );

			// If URL validates.
			if ( filter_var( $url, FILTER_VALIDATE_URL ) !== false ) {
				$return[ $service ] = $url;
			}
		}

		return $return;
	}
}

/**
 * Displays social media menu items as icons.
 *
 * @param string   $item_output The menu item's starting HTML output.
 * @param WP_Post  $item        Menu item data object.
 * @param int      $depth       Depth of menu item. Used for padding.
 * @param stdClass $args        An object of wp_nav_menu() arguments.
 *
 * @return string
 */
function float_plugin_nav_menu_social_icons( $item_output, $item, $depth, $args ) {

	if ( false === strpos( $args->menu_class, 'float-social-menu' ) ) {
		return $item_output;
	}

	// Supported social links icons.
	$social_links_icons = array(
		'bandcamp.com'    => 'bandcamp',
		'dribbble.com'    => 'dribbble',
		'facebook.com'    => 'facebook',
		'fb.me'           => 'facebook',
		'flickr.com'      => 'flickr',
		'goodreads.com'   => 'goodreads',
		'plus.google.com' => 'google',
		'google.com'      => 'google',
		'instagram.com'   => 'instagram',
		'itunes.com'      => 'itunes',
		'lastfm.com'      => 'lastfm',
		'linkedin.com'    => 'linkedin',
		'pinterest.'      => 'pinterest',
		'quora.com'       => 'quora',
		'soundcloud.com'  => 'soundcloud',
		'tumblr.com'      => 'tumblr',
		'twitter.com'     => 'x',
		'vimeo.com'       => 'vimeo',
		'vk.com'          => 'vk',
		'youtube.com'     => 'youtube',
	);

	foreach ( $social_links_icons as $attr => $value ) {
		if ( function_exists( 'float_get_inline_svg' ) && false !== strpos( $item->url, $attr ) ) {
			$item_output = '<a href="' . esc_url( $item->url ) . '" class="float-social-icon float-social-icon-' . $value . '">' . float_get_inline_svg( $value ) . '<span class="screen-reader-text">' . $attr . '</span></a>';
		}
	}

	return $item_output;

}
add_filter( 'walker_nav_menu_start_el', 'float_plugin_nav_menu_social_icons', 10, 4 );

/**
 * Adds a custom link to the end of a specific menu.
 *
 * @param  [type] $items [description].
 * @param  [type] $args [description].
 */
function float_plugin_wp_nav_menu_items( $items, $args ) {

	if ( function_exists( 'float_get_inline_svg' ) && false !== strpos( $args->menu_class, 'float-social-menu' ) ) {
		$items .= '<li><a href="' . get_bloginfo( 'rss2_url' ) . '" class="float-social-icon float-social-icon-rss">' . float_get_inline_svg( 'rss' ) . '<span class="screen-reader-text">RSS</span></a></li>';
	}

	return $items;
}
add_filter( 'wp_nav_menu_items', 'float_plugin_wp_nav_menu_items', 10, 2 );
