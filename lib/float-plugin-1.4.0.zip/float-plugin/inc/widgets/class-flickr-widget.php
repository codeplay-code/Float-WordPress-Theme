<?php
/**
 * Widget-flickr.php
 *
 * @package float-plugin
 */

/**
 * Core class used to implement the widget.
 */
class Flickr_Widget extends WP_Widget {

	/**
	 * Sets up the widget's name etc.
	 */
	function __construct() {
		$widget_ops = array(
			'classname'   => 'float-widget-flickr',
			'description' => __( 'Display images from Flickr.', 'float' ),
		);

		parent::__construct( 'Flickr_Widget', __( 'Float: Flickr Feed', 'float' ), $widget_ops );
	}

	/**
	 * Outputs the content of the widget.
	 *
	 * @param  array $args     Widget arguments.
	 * @param  array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {

		$title  = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Flickr Feed', 'float' );
		$id     = ( ! empty( $instance['id'] ) ) ? $instance['id'] : '';
		$number = ( ! empty( $instance['number'] ) ) ? $instance['number'] : 8;

		$title = apply_filters( 'widget_title', $title );

		echo wp_kses_post( $args['before_widget'] );

		if ( ! empty( $title ) ) {
			echo wp_kses_post( $args['before_title'] . wp_kses_post( wp_specialchars_decode( $title ) ) . $args['after_title'] );
		}
		?>

		<div class="float-widget-flickr-wrap">
			<script type="text/javascript" src="https://www.flickr.com/badge_code_v2.gne?count=<?php echo absint( $number ); ?>&amp;display=latest&amp;size=s&amp;layout=x&amp;source=user&amp;user=<?php echo esc_attr( $id ); ?>"></script>
		</div>

		<?php
		echo wp_kses_post( $args['after_widget'] );
	}

	/**
	 * Processing widget options on save.
	 *
	 * @param  array $new_instance Values just sent to be saved.
	 * @param  array $old_instance Previously saved values from database.
	 * @return array               Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {

		$instance = array();

		$instance['title']  = wp_strip_all_tags( $new_instance['title'] );
		$instance['id']     = esc_attr( $new_instance['id'] );
		$instance['number'] = absint( $new_instance['number'] );

		return $instance;
	}

	/**
	 * Outputs the options form on admin.
	 *
	 * @param  array $instance Previously saved values from database.
	 */
	function form( $instance ) {

		$instance = wp_parse_args(
			(array) $instance,
			array(
				'title'  => __( 'Flickr Feed', 'float' ),
				'id'     => '',
				'number' => 8,
			)
		);
		?>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'float' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr ( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_html( wp_strip_all_tags( $instance['title'] ) ); ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'id' ) ); ?>"><?php esc_html_e( 'Flickr ID', 'float' ); ?> (<a href="https://www.webfx.com/tools/idgettr/" target="_blank">idGettr</a>):</label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'id' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'id' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['id'] ); ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number (max. 10)', 'float' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo absint( $instance['number'] ); ?>">
		</p>

		<?php
	}
}

add_action( 'widgets_init', function() {
	register_widget( 'Flickr_Widget' );
});
