<?php
/**
 * Class-latest-widget.php
 *
 * @package float-plugin
 */

/**
 * Core class used to implement the widget.
 */
class Latest_Widget extends WP_Widget {

	/**
	 * Sets up the widget's name etc.
	 */
	function __construct() {
		$widget_ops = array(
			'classname'                   => 'float-widget-latest',
			'description'                 => __( 'Display posts with thumbnails.', 'float' ),
			'customize_selective_refresh' => true,
		);

		parent::__construct( 'Latest_Widget', __( 'Float: Posts with thumbnails', 'float' ), $widget_ops );
	}

	/**
	 * Outputs the content of the widget.
	 *
	 * @param  array $args     Widget arguments.
	 * @param  array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {

		$title   = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Latest Posts', 'float' );
		$orderby = ( ! empty( $instance['orderby'] ) ) ? $instance['orderby'] : 'date';
		$order   = ( ! empty( $instance['order'] ) ) ? $instance['order'] : 'DESC';
		$number  = ( ! empty( $instance['number'] ) ) ? $instance['number'] : 5;

		$title = apply_filters( 'widget_title', $title );

		echo wp_kses_post( $args['before_widget'] );

		if ( ! empty( $title ) ) {
			echo wp_kses_post( $args['before_title'] . wp_kses_post( wp_specialchars_decode( $title ) ) . $args['after_title'] );
		}

		$wp_query_args = array(
			'posts_per_page'         => $number,
			'meta_key'               => '_thumbnail_id', // phpcs:ignore slow query ok.
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'orderby'                => $orderby,
			'order'                  => $order,
		);

		$wp_query_posts = new WP_Query( $wp_query_args );
		?>

		<?php if ( $wp_query_posts->have_posts() ) : ?>
			<ul>
				<?php while ( $wp_query_posts->have_posts() ) : ?>
					<?php $wp_query_posts->the_post(); ?>
					<?php get_template_part( 'template-parts/template', 'article-smallest' ); ?>
				<?php endwhile; ?>
			</ul>
		<?php endif; ?>
		<?php wp_reset_postdata(); ?>

		<?php
		echo wp_kses_post( $args['after_widget'] );
	}

	/**
	 * Processing widget options on save.
	 *
	 * @param  array $new_instance Values just sent to be saved.
	 * @param  array $old_instance Previously saved values from database.
	 * @return array               Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {

		$instance = array();

		$instance['title']   = wp_strip_all_tags( $new_instance['title'] );
		$instance['orderby'] = esc_attr( $new_instance['orderby'] );
		$instance['order']   = esc_attr( $new_instance['order'] );
		$instance['number']  = absint( $new_instance['number'] );

		return $instance;
	}

	/**
	 * Outputs the options form on admin.
	 *
	 * @param  array $instance Previously saved values from database.
	 */
	function form( $instance ) {

		$instance = wp_parse_args(
			(array) $instance,
			array(
				'title'   => __( 'Latest Posts', 'float' ),
				'orderby' => 'date',
				'order'   => 'DESC',
				'number'  => 5,
			)
		);
		?>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'float' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_html( wp_strip_all_tags( $instance['title'] ) ); ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'orderby' ) ); ?>"><?php esc_html_e( 'Order by:', 'float' ); ?></label>
			<select name="<?php echo esc_attr( $this->get_field_name( 'orderby' ) ); ?>" class="widefat">
				<option value="date" <?php selected( $instance['orderby'], 'date' ); ?>><?php esc_html_e( 'Date', 'float' ); ?></option>
				<option value="comment_count" <?php selected( $instance['orderby'], 'comment_count' ); ?>><?php esc_html_e( 'Comment count', 'float' ); ?></option>
			</select>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'order' ) ); ?>"><?php esc_html_e( 'Order:', 'float' ); ?></label>
			<select name="<?php echo esc_attr( $this->get_field_name( 'order' ) ); ?>" class="widefat">
				<option value="ASC" <?php selected( $instance['order'], 'ASC' ); ?>><?php esc_html_e( 'Ascending', 'float' ); ?></option>
				<option value="DESC" <?php selected( $instance['order'], 'DESC' ); ?>><?php esc_html_e( 'Descending', 'float' ); ?></option>
			</select>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of posts to show:', 'float' ); ?></label>
			<input id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo absint( $instance['number'] ); ?>" size="3">
		</p>

		<?php
	}
}

add_action( 'widgets_init', function() {
	register_widget( 'Latest_Widget' );
});
