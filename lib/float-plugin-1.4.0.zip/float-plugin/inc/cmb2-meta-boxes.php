<?php
/**
 * Meta-boxes.php
 *
 * CMB2 Meta Boxes.
 *
 * @package CMB2
 * @link https://github.com/WebDevStudios/CMB2
 */

/**
 * Creates meta box.
 */
function float_cmb2_meta_single_post() {

	$cmb = new_cmb2_box( array(
		'id'           => 'float_meta_single_post',
		'title'        => __( 'Post Meta', 'float' ),
		'object_types' => array( 'post' ),
		'context'      => 'side',
		'priority'     => 'default',
		'show_names'   => true, // Show field names on the left.
		'closed'       => false, // True to keep the metabox closed by default.
	) );

	$cmb->add_field( array(
		'name' => __( "Don't show the featured image at the beginning of the post.", 'float' ),
		'id'   => '_float_meta_hide_featured_image', // custom_meta_featured.
		'type' => 'checkbox',
	) );
}
add_action( 'cmb2_admin_init', 'float_cmb2_meta_single_post' );

/**
 * Creates meta box for the user profile screen.
 */
function float_cmb2_meta_user() {

	$cmb_user = new_cmb2_box( array(
		'id'               => 'user_edit',
		'title'            => __( 'Social Links', 'float' ),
		'object_types'     => array( 'user' ), // Tells CMB2 to use user_meta vs post_meta.
		'show_names'       => true,
		'new_user_section' => 'add-new-user', // Where form will show on new user page. 'add-existing-user' is only other valid option.
	) );

	$cmb_user->add_field( array(
		'name'     => __( 'Social Links', 'float' ),
		'id'       => '_float_meta_title_1',
		'type'     => 'title',
		'on_front' => false,
	) );

	$cmb_user->add_field( array(
		'name' => __( 'Facebook URL', 'float' ),
		'id'   => '_float_meta_facebook_url',
		'type' => 'text_url',
	) );

	$cmb_user->add_field( array(
		'name' => __( 'Instagram URL', 'float' ),
		'id'   => '_float_meta_instagram_url',
		'type' => 'text_url',
	) );

	$cmb_user->add_field( array(
		'name' => __( 'Pinterest URL', 'float' ),
		'id'   => '_float_meta_pinterest_url',
		'type' => 'text_url',
	) );

	$cmb_user->add_field( array(
		'name' => __( 'Twitter URL', 'float' ),
		'id'   => '_float_meta_twitter_url',
		'type' => 'text_url',
	) );
}
add_action( 'cmb2_admin_init', 'float_cmb2_meta_user' );
