<?php
/**
 * Shortcodes.php
 *
 * @package float-plugin
 */

/**
 * Buttons.
 *
 * @param array  $atts Atts.
 * @param string $content Content.
 * @return string
 */
function float_shortcode_button( $atts, $content = null ) {

	$a = shortcode_atts( array(
		'url'   => '#',
		'color' => 'gray',
	), $atts );

	return '<a href="' . esc_url( $a['url'] ) . '" class="button ' . esc_attr( $a['color'] ) . '">' . do_shortcode( $content ) . '</a>';
}
add_shortcode( 'button', 'float_shortcode_button' );

/**
 * Alerts.
 *
 * @param array  $atts Atts.
 * @param string $content Content.
 * @return string
 */
function float_shortcode_alert( $atts, $content = null ) {

	$a = shortcode_atts( array(
		'color' => 'yellow',
	), $atts );

	return '<p class="alert ' . esc_attr( $a['color'] ) . '">' . do_shortcode( $content ) . '</p>';
}
add_shortcode( 'alert', 'float_shortcode_alert' );

/**
 * Columns.
 *
 * @param array  $atts Atts.
 * @param string $content Content.
 * @return string
 */
function float_shortcode_one_half( $atts, $content = null ) {
	return '<div class="one_half">' . do_shortcode( $content ) . '</div>';
}
add_shortcode( 'one_half', 'float_shortcode_one_half' );

/**
 * Columns.
 *
 * @param array  $atts Atts.
 * @param string $content Content.
 * @return string
 */
function float_shortcode_one_half_last( $atts, $content = null ) {
	return '<div class="one_half last">' . do_shortcode( $content ) . '</div><div class="clear"></div>';
}
add_shortcode( 'one_half_last', 'float_shortcode_one_half_last' );

/**
 * Columns.
 *
 * @param array  $atts Atts.
 * @param string $content Content.
 * @return string
 */
function float_shortcode_one_third( $atts, $content = null ) {
	return '<div class="one_third">' . do_shortcode( $content ) . '</div>';
}
add_shortcode( 'one_third', 'float_shortcode_one_third' );

/**
 * Columns.
 *
 * @param array  $atts Atts.
 * @param string $content Content.
 * @return string
 */
function float_shortcode_one_third_last( $atts, $content = null ) {
	return '<div class="one_third last">' . do_shortcode( $content ) . '</div><div class="clear"></div>';
}
add_shortcode( 'one_third_last', 'float_shortcode_one_third_last' );

/**
 * Columns.
 *
 * @param array  $atts Atts.
 * @param string $content Content.
 * @return string
 */
function float_shortcode_one_fourth( $atts, $content = null ) {
	return '<div class="one_fourth">' . do_shortcode( $content ) . '</div>';
}
add_shortcode( 'one_fourth', 'float_shortcode_one_fourth' );

/**
 * Columns.
 *
 * @param array  $atts Atts.
 * @param string $content Content.
 * @return string
 */
function float_shortcode_one_fourth_last( $atts, $content = null ) {
	return '<div class="one_fourth last">' . do_shortcode( $content ) . '</div><div class="clear"></div>';
}
add_shortcode( 'one_fourth_last', 'float_shortcode_one_fourth_last' );
