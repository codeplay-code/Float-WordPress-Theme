<?php
/**
 * Class-social-widget.php
 *
 * @package float-plugin
 */

/**
 * Core class used to implement the widget.
 */
class Social_Widget extends WP_Widget {

	/**
	 * Sets up the widget's name etc.
	 */
	function __construct() {
		$widget_ops = array(
			'classname'                   => 'float-widget-social',
			'description'                 => __( 'Display links to popular services like Facebook and Twitter.', 'float' ),
			'customize_selective_refresh' => true,
		);

		parent::__construct( 'Social_Widget', __( 'Float: Social Links', 'float' ), $widget_ops );
	}

	/**
	 * Outputs the content of the widget.
	 *
	 * @param  array $args     Widget arguments.
	 * @param  array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {

		$title   = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Follow Me', 'float' );
		$content = ( ! empty( $instance['content'] ) ) ? $instance['content'] : '';
		$menu    = ( ! empty( $instance['menu'] ) ) ? $instance['menu'] : '';

		$colored = get_theme_mod( 'social_icons_in_color', true );

		$title = apply_filters( 'widget_title', $title );

		echo wp_kses_post( $args['before_widget'] );

		if ( ! empty( $title ) ) {
			echo wp_kses_post( $args['before_title'] . wp_kses_post( wp_specialchars_decode( $title ) ) . $args['after_title'] );
		}

		if ( ! empty( $content ) ) {
			echo wp_kses_post( wp_specialchars_decode( wpautop( $content ) ) );
		}

		if ( ! empty( $menu ) ) {
			wp_nav_menu( array(
				'menu'       => $menu,
				'menu_class' => 'float-social-menu ' . ( true === $colored ? 'float-social-menu-color' : 'float-social-menu-grayscale' ),
			) );
		}

		echo wp_kses_post( $args['after_widget'] );
	}

	/**
	 * Processing widget options on save.
	 *
	 * @param  array $new_instance Values just sent to be saved.
	 * @param  array $old_instance Previously saved values from database.
	 * @return array               Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {

		$instance = array();

		$instance['title']   = wp_strip_all_tags( $new_instance['title'] );
		$instance['content'] = esc_html( $new_instance['content'] );
		$instance['menu']    = esc_attr( $new_instance['menu'] );

		return $instance;
	}

	/**
	 * Outputs the options form on admin.
	 *
	 * @param  array $instance Previously saved values from database.
	 */
	function form( $instance ) {

		$instance = wp_parse_args(
			(array) $instance,
			array(
				'title'   => __( 'Follow Me', 'float' ),
				'content' => '',
				'menu'    => '',
			)
		);

		$menus = get_terms( 'nav_menu', array( 'hide_empty' => true ) );
		?>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'float' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_html( wp_strip_all_tags( $instance['title'] ) ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>"><?php esc_html_e( 'Content', 'float' ); ?>:</label>
			<textarea rows="6" name="<?php echo esc_attr( $this->get_field_name( 'content' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>" class="widefat"><?php echo esc_html( wp_strip_all_tags( $instance['content'] ) ); ?></textarea>
		</p>

		<?php if ( ! empty( $menus ) ) : ?>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'menu' ) ); ?>"><?php esc_html_e( 'Menu:', 'float' ); ?></label>
				<select name="<?php echo esc_attr( $this->get_field_name( 'menu' ) ); ?>" class="widefat">
				<?php foreach ( $menus as $menu ) : ?>
					<option value="<?php echo esc_attr( $menu->slug ); ?>" <?php selected( $instance['menu'], $menu->slug ); ?>><?php echo esc_html( $menu->name ); ?></option>
				<?php endforeach; ?>
				</select>
			</p>
		<?php endif; ?>

		<?php
	}
}

add_action( 'widgets_init', function() {
	register_widget( 'Social_Widget' );
});
