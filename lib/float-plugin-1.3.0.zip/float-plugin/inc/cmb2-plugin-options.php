<?php
/**
 * Cmb2-theme-options.php.
 *
 * @package float-plugin
 */

/**
 * Registers a metabox to handle the theme options.
 */
function float_cmb2_box_theme_options() {

	/**
	 * Registers main options page menu item and form.
	 */
	$options = new_cmb2_box( array(
		'id'           => 'float_main_options_page',
		'title'        => __( 'Float Options', 'float' ),
		'object_types' => array( 'options-page' ),
		'option_key'   => 'float_options',
	) );

	$options->add_field( array(
		'name' => __( 'Analytics', 'float' ),
		'desc' => __( 'Optional tracking code for the analytics services, for example Google Analytics.', 'float' ),
		'id'   => 'analytics',
		'type' => 'textarea_code',
	) );

	$options->add_field( array(
		'name'    => 'Options Saved',
		'id'      => 'options_saved',
		'type'    => 'hidden',
		'default' => date( 'H:i:s Y-m-d' ),
	) );
}
add_action( 'cmb2_admin_init', 'float_cmb2_box_theme_options' );
