<?php
/**
 * Misc.php
 *
 * @package float-plugin
 */

if ( function_exists( 'float_get_option' ) && float_get_option( 'analytics' ) && ! function_exists( 'float_inline_script' ) ) {
	/**
	 * Enqueues analytics script to the footer.
	 */
	function float_inline_script() {
		echo float_get_option( 'analytics' );
	}
	add_action( 'wp_footer', 'float_inline_script' );
}

/**
 * Excludes pages from search.
 *
 * @param  array $query Query.
 * @return array
 */
function float_pre_get_posts( $query ) {
	if ( is_search() && $query->is_search ) {
		$query->set( 'post_type', 'post' );
	}
	return $query;
}
add_filter( 'pre_get_posts', 'float_pre_get_posts' );

/**
 * Adds custom styles dropdown to editor.
 *
 * @param  array $buttons Buttons.
 * @return array
 */
function float_mce_buttons_2( $buttons ) {
	array_unshift( $buttons, 'styleselect' );
	return $buttons;
}
add_filter( 'mce_buttons_2', 'float_mce_buttons_2' );

/**
 * Adds custom styles dropdown to editor.
 *
 * @param  array $settings Settings.
 * @return array
 */
function float_tiny_mce_before_init( $settings ) {

	$style_formats = array(
		array(
			'title'   => 'Ingress',
			'block'   => 'p',
			'classes' => 'ingress',
		),
	);

	$settings['style_formats'] = wp_json_encode( $style_formats );

	return $settings;
}
add_filter( 'tiny_mce_before_init', 'float_tiny_mce_before_init' );

/**
 * Allows shortcodes in widgets.
 */
add_filter( 'widget_text', 'shortcode_unautop' );
add_filter( 'widget_text', 'do_shortcode' );
