<?php
/**
 * Plugin Name: Float Plugin
 * Plugin URI: https://themeforest.net/item/float-responsive-blog-theme/2635174?ref=mytheme
 * Author: myTheme
 * Author URI: https://themeforest.net/user/mytheme/portfolio?ref=mytheme
 * Description: Plugin required by <a href="https://themeforest.net/item/float-responsive-blog-theme/2635174?ref=mytheme">Float Theme</a>.
 * License: GNU General Public License
 * License URI: license.txt
 * Text Domain: float
 * Version: 1.3.0
 *
 * @package float-plugin
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'FLOAT_PLUGIN_DIR_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Sets a constant for the plugin URL.
 */
add_action( 'init', function() {
	define( 'FLOAT_PLUGIN_BASE_PLUGIN_URL', plugins_url( '', __FILE__ ) );
} );

if ( ! function_exists( 'float_get_option' ) ) {
	/**
	 * Wrapper function around cmb2_get_option.
	 *
	 * @param  string $key     Options array key.
	 * @param  mixed  $default Optional default value.
	 * @return mixed           Option value.
	 */
	function float_get_option( $key = '', $default = false ) {

		if ( function_exists( 'cmb2_get_option' ) ) {
			return cmb2_get_option( 'float_options', $key, $default );
		}

		// Fallback to get_option if CMB2 is not loaded yet.
		$opts = get_option( 'float_options', $default );
		$val  = $default;
		if ( 'all' === $key ) {
			$val = $opts;
		} elseif ( is_array( $opts ) && array_key_exists( $key, $opts ) && false !== $opts[ $key ] ) {
			$val = $opts[ $key ];
		}
		return $val;
	}
}

/**
 * Requires files from /inc folder.
 */
require FLOAT_PLUGIN_DIR_PATH . 'inc/admin-functions.php';
require FLOAT_PLUGIN_DIR_PATH . 'inc/cmb2-plugin-options.php';
require FLOAT_PLUGIN_DIR_PATH . 'inc/cmb2-meta-boxes.php';
require FLOAT_PLUGIN_DIR_PATH . 'inc/misc.php';
require FLOAT_PLUGIN_DIR_PATH . 'inc/shortcodes.php';
require FLOAT_PLUGIN_DIR_PATH . 'inc/social-links.php';
require FLOAT_PLUGIN_DIR_PATH . 'inc/tinymce/tinymce.php';
require FLOAT_PLUGIN_DIR_PATH . 'inc/widgets/class-flickr-widget.php';
require FLOAT_PLUGIN_DIR_PATH . 'inc/widgets/class-latest-widget.php';
require FLOAT_PLUGIN_DIR_PATH . 'inc/widgets/class-postit-widget.php';
require FLOAT_PLUGIN_DIR_PATH . 'inc/widgets/class-social-widget.php';
