<?php
/**
 * Tinymce.php
 *
 * @package float-plugin
 */

/**
 * Adds buttons for shortcodes to the TinyMCE editor.
 */
function float_add_button() {
	if ( current_user_can( 'edit_posts' ) && current_user_can( 'edit_pages' ) ) {
		add_filter( 'mce_external_plugins', 'float_add_plugin' );
		add_filter( 'mce_buttons_2', 'float_register_button' );
	}
}
add_action( 'init', 'float_add_button' );

/**
 * Registers buttons.
 *
 * @param  array $buttons Buttons.
 * @return array
 */
function float_register_button( $buttons ) {
	array_push( $buttons, '|', 'columns', 'buttons', 'alerts' );
	return $buttons;
}

/**
 * Adds plugin.
 *
 * @param  array $plugin_array Plugin.
 * @return array
 */
function float_add_plugin( $plugin_array ) {
	$plugin_array['shortcodes'] = FLOAT_PLUGIN_BASE_PLUGIN_URL . '/inc/tinymce/shortcodes.js';
	return $plugin_array;
}
