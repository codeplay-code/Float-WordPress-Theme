(function() {

	function addColumnsButton(ed, url){
		ed.addButton('columns', {
			title : 'Add column shortcodes',
			image : url+'/images/shortcodes-columns.png',
			onclick : function() {
				var columns = prompt("Number of columns (2, 3, 4)", "2");

				if (columns == '2'){
					ed.execCommand('mceInsertContent', false, '[one_half]Text goes here...[/one_half]');
					ed.execCommand('mceInsertContent', false, '[one_half_last]Text goes here...[/one_half_last]');
				}

				if (columns == '3'){
					ed.execCommand('mceInsertContent', false, '[one_third]Text goes here...[/one_third]');
					ed.execCommand('mceInsertContent', false, '[one_third]Text goes here...[/one_third]');
					ed.execCommand('mceInsertContent', false, '[one_third_last]Text goes here...[/one_third_last]');
				}

				if (columns == '4'){
					ed.execCommand('mceInsertContent', false, '[one_fourth]Text goes here...[/one_fourth]');
					ed.execCommand('mceInsertContent', false, '[one_fourth]Text goes here...[/one_fourth]');
					ed.execCommand('mceInsertContent', false, '[one_fourth]Text goes here...[/one_fourth]');
					ed.execCommand('mceInsertContent', false, '[one_fourth_last]Text goes here...[/one_fourth_last]');
				}

			}
		});
	}

	function addButtonsButton(ed, url){
		ed.addButton('buttons', {
			title : 'Add button shortcodes',
			image : url+'/images/shortcodes-buttons.png',
			onclick : function() {
				var color = prompt("Button color", "blue");
				var text = prompt("Button text", "Button text...");
				var url = prompt("Button URL", "http://");

				if (color != '' && color != null){
					ed.execCommand('mceInsertContent', false, '[button url="'+url+'" color="'+color+'"]'+text+'[/button]');
				}
			}
		});
	}

	function addAlertsButton(ed, url){
		ed.addButton('alerts', {
			title : 'Add alert shortcodes',
			image : url+'/images/shortcodes-alerts.png',
			onclick : function() {
				var color = prompt("Alert color", "yellow");

				if (color != '' && color != null){
					ed.execCommand('mceInsertContent', false, '[alert color="'+color+'"]Text goes here...[/alert]');
				}
			}
		});
	}

	tinymce.create('tinymce.plugins.shortcodes', {
		init : function(ed, url) {
			addColumnsButton(ed, url);
			addButtonsButton(ed,url);
			addAlertsButton(ed,url);
		},
		createControl : function(n, cm) {
			return null;
		},
	});

	tinymce.PluginManager.add('shortcodes', tinymce.plugins.shortcodes);
})();
