<?php
/**
 * Class-postit-widget.php
 *
 * @package float-plugin
 */

/**
 * Core class used to implement the widget.
 */
class Postit_Widget extends WP_Widget {

	/**
	 * Sets up the widget's name etc.
	 */
	function __construct() {
		$widget_ops = array(
			'classname'                   => 'float-widget-postit',
			'description'                 => __( 'Display content in a Post-it note.', 'float' ),
			'customize_selective_refresh' => true,
		);

		parent::__construct( 'Postit_Widget', __( 'Float: Post-it Note', 'float' ), $widget_ops );
	}

	/**
	 * Outputs the content of the widget.
	 *
	 * @param  array $args     Widget arguments.
	 * @param  array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {

		$title  = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Custom Post-it Widget', 'float' );
		$text   = ( ! empty( $instance['text'] ) ) ? $instance['text'] : '';
		$filter = ( ! empty( $instance['filter'] ) ) ? $instance['filter'] : '';

		$title = apply_filters( 'widget_title', $title );

		echo wp_kses_post( $args['before_widget'] );
		echo '<div class="float-widget-postit-inner">';

		if ( ! empty( $title ) ) {
			echo wp_kses_post( $args['before_title'] . wp_kses_post( wp_specialchars_decode( $title ) ) . $args['after_title'] );
		}

		echo wp_kses_post( $filter ? wpautop( $text ) : $text );
		echo '</div>';
		echo wp_kses_post( $args['after_widget'] );
	}

	/**
	 * Processing widget options on save.
	 *
	 * @param  array $new_instance Values just sent to be saved.
	 * @param  array $old_instance Previously saved values from database.
	 * @return array               Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {

		$instance = array();

		$instance['title']  = wp_strip_all_tags( $new_instance['title'] );
		$instance['text']   = $new_instance['text'];
		$instance['filter'] = isset( $new_instance['filter'] );

		return $instance;
	}

	/**
	 * Outputs the options form on admin.
	 *
	 * @param  array $instance Previously saved values from database.
	 */
	function form( $instance ) {

		$instance = wp_parse_args(
			(array) $instance,
			array(
				'title'  => __( 'Custom Post-it Widget', 'float' ),
				'text'   => '',
				'filter' => '',
			)
		);
		?>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'float' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_html( wp_strip_all_tags( $instance['title'] ) ); ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'text' ) ); ?>"><?php esc_html_e( 'Content', 'float' ); ?>:</label>
			<textarea class="widefat" rows="6" id="<?php echo esc_attr( $this->get_field_id( 'text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'text' ) ); ?>"><?php echo esc_html( $instance['text'] ); ?></textarea>
		</p>

		<p>
			<input id="<?php echo esc_attr( $this->get_field_id( 'filter' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'filter' ) ); ?>" type="checkbox" <?php checked(isset( $instance['filter'] ) ? $instance['filter'] : 0 ); ?> />&nbsp;<label for="<?php echo esc_attr( $this->get_field_id( 'filter' ) ); ?>"><?php esc_html_e( 'Automatically add paragraphs', 'float' ); ?></label>
		</p>

		<?php
	}
}

add_action( 'widgets_init', function() {
	register_widget( 'Postit_Widget' );
});
