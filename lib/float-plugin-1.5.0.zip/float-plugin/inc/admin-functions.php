<?php
/**
 * Admin-functions.php
 *
 * @package float-plugin
 */

if ( ! function_exists( 'float_manage_posts_custom_column' ) ) {
	/**
	 * Adds columns to the custom post type listing.
	 *
	 * @param  string $column  The name of the column to display.
	 * @param  int    $post_id The ID of the current post.
	 */
	function float_manage_posts_custom_column( $column, $post_id ) {

		switch ( $column ) {
			case 'featured_image':
				echo get_the_post_thumbnail( $post_id );
				break;
		}
	}
}
add_action( 'manage_posts_custom_column', 'float_manage_posts_custom_column', 10, 2 );

if ( ! function_exists( 'float_manage_posts_columns' ) ) {
	/**
	 * Adds columns to the custom post type listing.
	 *
	 * @param  array $columns An array of column name and label.
	 */
	function float_manage_posts_columns( $columns ) {

		return array_merge(
			$columns,
			array(
				'featured_image' => __( 'Featured Image', 'float' ),
			)
		);
	}
}
add_filter( 'manage_posts_columns', 'float_manage_posts_columns' );
